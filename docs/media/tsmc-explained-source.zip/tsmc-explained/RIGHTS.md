# 實際素材與授權記錄

這是 bigtongue5566 自行製作的非官方公司介紹 Demo，未獲台積電委託、贊助、核准或背書。

- **文字與事實**：公司資訊由公開官方資料核對，再以自己的文字整理。逐段內容、來源網址、事件／數據年度及查核日期列於 [SOURCES.md](SOURCES.md) 和 [claims.json](claims.json)。沒有搬用官方宣傳段落。
- **圖形與動畫**：自行繪製的晶圓、電路、製程及封裝概念；不是官方工程圖或實拍。本案沒有納入公司 Logo、官網圖表、照片、影片、新聞畫面或人物肖像。
- **配樂**：原創作曲與電子打擊／低音，鋼琴使用 S. Christian Collins 的 GeneralUser GS 2.0.3 取樣音源，由 FluidSynth 演奏；沒有使用第三方歌曲。官方 License v2.0 允許私人與商業音樂創作；授權同時保留部分樣本最初來源無法完全確認的說明，原文附於 licenses/GeneralUser-GS-LICENSE.txt。音源未打包，重現下載固定官方 commit 與 SHA-256。可編輯 MIDI 和程式已附上。
- **字型**：Noto Sans CJK TC 與 Space Grotesk，使用 SIL Open Font License 1.1。實際來源 commit、網址與 SHA-256 見 sources.json；未修改的授權原文見 licenses/。
- **程式與原創部分**：依本來源包的 MIT LICENSE 提供。MIT 不授予台積電名稱、商標、任何第三方作品或字型的其他權利；字型仍依 OFL 條款。

公司名稱只用來辨識介紹對象，以一般文字排版呈現。配色是本片獨立的編輯設計，沒有宣稱採用官方品牌規範。影片持續標示「非官方介紹・圖形為概念示意」。

台積電官網的 [Legal Notice and Trademark Information](https://www.tsmc.com/english/legal_and_trademark) 限制其網站內容及商標的使用。這份聲明僅作為素材選擇的參考，不是對本片的授權。

附來源不等於取得使用授權，也不能保證不會被提出法律主張。本記錄說明本次實際使用的材料及已採取的做法，不是法律意見或權利清查證書。重新加入官方素材、改成廣告、聲稱合作或用於其他用途時，需另行確認適用權利與使用範圍。
